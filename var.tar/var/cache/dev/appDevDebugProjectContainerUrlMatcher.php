<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_wdt']), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_search_results']), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler']), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_router']), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception']), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception_css']), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_twig_error_test']), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        elseif (0 === strpos($pathinfo, '/a')) {
            if (0 === strpos($pathinfo, '/api/article')) {
                // rest_api_articles
                if ('/api/articles' === $pathinfo) {
                    return array (  '_controller' => 'SoftUniBlogRestApiBundle\\Controller\\ArticleController::all',  '_route' => 'rest_api_articles',);
                }

                // rest_api_article
                if (preg_match('#^/api/article/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'rest_api_article']), array (  '_controller' => 'SoftUniBlogRestApiBundle\\Controller\\ArticleController::view',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_rest_api_article;
                    }

                    return $ret;
                }
                not_rest_api_article:

                // rest_api_article_edit
                if (0 === strpos($pathinfo, '/api/articles') && preg_match('#^/api/articles/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'rest_api_article_edit']), array (  '_controller' => 'SoftUniBlogRestApiBundle\\Controller\\ArticleController::editAction',));
                }

            }

            // admin_users
            if ('/admin/users' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\AdminController::indexAction',  '_route' => 'admin_users',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_admin_users;
                }

                return $ret;
            }
            not_admin_users:

            if (0 === strpos($pathinfo, '/article')) {
                // article_view
                if (preg_match('#^/article/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'article_view']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::view',));
                }

                // my_articles
                if ('/articles/my_articles' === $pathinfo) {
                    return array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::getAllArticlesByUser',  '_route' => 'my_articles',);
                }

            }

        }

        elseif (0 === strpos($pathinfo, '/create')) {
            // article_create
            if ('/create' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::create',  '_route' => 'article_create',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_article_create;
                }

                return $ret;
            }
            not_article_create:

            // softuniblog_article_createprocess
            if ('/create' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::createProcess',  '_route' => 'softuniblog_article_createprocess',);
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_softuniblog_article_createprocess;
                }

                return $ret;
            }
            not_softuniblog_article_createprocess:

        }

        // comment_create
        if (0 === strpos($pathinfo, '/comment/create') && preg_match('#^/comment/create/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
            $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'comment_create']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\CommentController::create',));
            if (!in_array($requestMethod, ['POST'])) {
                $allow = array_merge($allow, ['POST']);
                goto not_comment_create;
            }

            return $ret;
        }
        not_comment_create:

        if (0 === strpos($pathinfo, '/edit')) {
            // article_edit
            if (preg_match('#^/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'article_edit']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::edit',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_article_edit;
                }

                return $ret;
            }
            not_article_edit:

            // softuniblog_article_editprocess
            if (preg_match('#^/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'softuniblog_article_editprocess']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::editProcess',));
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_softuniblog_article_editprocess;
                }

                return $ret;
            }
            not_softuniblog_article_editprocess:

        }

        elseif (0 === strpos($pathinfo, '/delete')) {
            // article_delete
            if (preg_match('#^/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'article_delete']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::delete',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_article_delete;
                }

                return $ret;
            }
            not_article_delete:

            // softuniblog_article_deleteprocess
            if (preg_match('#^/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'softuniblog_article_deleteprocess']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\ArticleController::deleteProcess',));
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_softuniblog_article_deleteprocess;
                }

                return $ret;
            }
            not_softuniblog_article_deleteprocess:

            if (0 === strpos($pathinfo, '/delete/message')) {
                // message_delete
                if (preg_match('#^/delete/message/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'message_delete']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\MessageController::delete',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_message_delete;
                    }

                    return $ret;
                }
                not_message_delete:

                // softuniblog_message_deleteprocess
                if (preg_match('#^/delete/message/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'softuniblog_message_deleteprocess']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\MessageController::deleteProcess',));
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_softuniblog_message_deleteprocess;
                    }

                    return $ret;
                }
                not_softuniblog_message_deleteprocess:

            }

        }

        elseif (0 === strpos($pathinfo, '/user')) {
            // user_message
            if (preg_match('#^/user/(?P<id>[^/]++)/message$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'user_message']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\CommentController::addUserMessage',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_user_message;
                }

                return $ret;
            }
            not_user_message:

            // message_create
            if (preg_match('#^/user/(?P<id>[^/]++)/message/create$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'message_create']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\MessageController::create',));
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_message_create;
                }

                return $ret;
            }
            not_message_create:

            // user_mailbox
            if ('/user/mailbox' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\MessageController::getAllByUser',  '_route' => 'user_mailbox',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_user_mailbox;
                }

                return $ret;
            }
            not_user_mailbox:

            if (0 === strpos($pathinfo, '/user/mailbox/message')) {
                // user_mailbox_message
                if (preg_match('#^/user/mailbox/message/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'user_mailbox_message']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\MessageController::view',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_user_mailbox_message;
                    }

                    return $ret;
                }
                not_user_mailbox_message:

                // user_mailbox_send_message
                if (preg_match('#^/user/mailbox/message/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'user_mailbox_send_message']), array (  '_controller' => 'SoftUniBlogBundle\\Controller\\MessageController::sendMessageToSender',));
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_user_mailbox_send_message;
                    }

                    return $ret;
                }
                not_user_mailbox_send_message:

            }

        }

        // blog_index
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\HomeController::indexAction',  '_route' => 'blog_index',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_blog_index;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'blog_index'));
            }

            return $ret;
        }
        not_blog_index:

        // security_login
        if ('/login' === $pathinfo) {
            return array (  '_controller' => 'SoftUniBlogBundle\\Controller\\SecurityController::login',  '_route' => 'security_login',);
        }

        // security_logout
        if ('/logout' === $pathinfo) {
            return array (  '_controller' => 'SoftUniBlogBundle\\Controller\\UserController::logout',  '_route' => 'security_logout',);
        }

        if (0 === strpos($pathinfo, '/register')) {
            // user_register
            if ('/register' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\UserController::register',  '_route' => 'user_register',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_user_register;
                }

                return $ret;
            }
            not_user_register:

            // softuniblog_user_registerprocess
            if ('/register' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\UserController::registerProcess',  '_route' => 'softuniblog_user_registerprocess',);
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_softuniblog_user_registerprocess;
                }

                return $ret;
            }
            not_softuniblog_user_registerprocess:

        }

        // user_profile
        if ('/profile' === $pathinfo) {
            return array (  '_controller' => 'SoftUniBlogBundle\\Controller\\UserController::profile',  '_route' => 'user_profile',);
        }

        if (0 === strpos($pathinfo, '/profile/edit')) {
            // user_edit_profile
            if ('/profile/edit' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\UserController::edit',  '_route' => 'user_edit_profile',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_user_edit_profile;
                }

                return $ret;
            }
            not_user_edit_profile:

            // softuniblog_user_editprocess
            if ('/profile/edit' === $pathinfo) {
                $ret = array (  '_controller' => 'SoftUniBlogBundle\\Controller\\UserController::editProcess',  '_route' => 'softuniblog_user_editprocess',);
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_softuniblog_user_editprocess;
                }

                return $ret;
            }
            not_softuniblog_user_editprocess:

        }

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
