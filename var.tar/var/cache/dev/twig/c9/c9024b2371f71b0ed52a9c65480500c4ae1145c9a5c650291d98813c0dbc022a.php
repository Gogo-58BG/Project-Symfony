<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_52b81562d8f88d5a40e23c3caf8e66e075075c9f7d63fa66e046b693ff07a759 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 5, $this->source); })()), "session", [], "any", false, false, false, 5), "flashBag", [], "any", false, false, false, 5), "get", [0 => "info"], "method", false, false, false, 5));
        foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
            // line 6
            echo "        <div class=\"alert alert-success\" id=\"info\">
            ";
            // line 7
            echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "
    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 11, $this->source); })()), "session", [], "any", false, false, false, 11), "flashBag", [], "any", false, false, false, 11), "get", [0 => "errors"], "method", false, false, false, 11));
        foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
            // line 12
            echo "        <div class=\"alert alert-success\">
            ";
            // line 13
            echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
            echo "
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" area-label=\"Close\">
                <span area-hidden=\"true\">&times;</span>
            </button>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "
    <div class=\"container body-content\">
        <div class=\"row\">
            ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["articles"]) || array_key_exists("articles", $context) ? $context["articles"] : (function () { throw new RuntimeError('Variable "articles" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 23
            echo "                <div class=\"col-md-6\">
                    <div class=\"vl\">
                    <article>
                        <header>
                            <h2>";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "title", [], "any", false, false, false, 27), "html", null, true);
            echo "</h2>
                        </header>
                        ";
            // line 29
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["article"], "image", [], "any", false, false, false, 29))) {
                // line 30
                echo "                            <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("article_view", ["id" => twig_get_attribute($this->env, $this->source, $context["article"], "id", [], "any", false, false, false, 30)]), "html", null, true);
                echo "\">
                                <img src=\"";
                // line 31
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/images/articles/" . twig_get_attribute($this->env, $this->source, $context["article"], "image", [], "any", false, false, false, 31))), "html", null, true);
                echo "\" width=\"400px\" height=\"200px\">
                            </a>
                        ";
            }
            // line 34
            echo "
                        <p>
                            ";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "summary", [], "any", false, false, false, 36), "html", null, true);
            echo "
                        </p>

                        <small class=\"author\">
                            Author: ";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["article"], "author", [], "any", false, false, false, 40), "fullName", [], "any", false, false, false, 40), "html", null, true);
            echo "
                        </small>

                        <small>
                            Views:";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "viewCount", [], "any", false, false, false, 44), "html", null, true);
            echo "
                        </small><br>

                        <small>
                            Date Added:";
            // line 48
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "dateAdded", [], "any", false, false, false, 48), "F jS \\a\\t g:ia"), "html", null, true);
            echo "
                        </small>


                            <div class=\"pull-right\">
                                <div class=\"v2\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("article_view", ["id" => twig_get_attribute($this->env, $this->source, $context["article"], "id", [], "any", false, false, false, 55)]), "html", null, true);
            echo "\">Read more &raquo;</a>
                            </div></div>

                    </article></div>
                    <hr class=\"new\">
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "        </div>
    </div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  190 => 62,  177 => 55,  167 => 48,  160 => 44,  153 => 40,  146 => 36,  142 => 34,  136 => 31,  131 => 30,  129 => 29,  124 => 27,  118 => 23,  114 => 22,  109 => 19,  97 => 13,  94 => 12,  90 => 11,  87 => 10,  78 => 7,  75 => 6,  71 => 5,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}

    {% for msg in app.session.flashBag.get(\"info\") %}
        <div class=\"alert alert-success\" id=\"info\">
            {{ msg }}
        </div>
    {% endfor %}

    {% for msg in app.session.flashBag.get(\"errors\") %}
        <div class=\"alert alert-success\">
            {{ msg }}
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" area-label=\"Close\">
                <span area-hidden=\"true\">&times;</span>
            </button>
        </div>
    {% endfor %}

    <div class=\"container body-content\">
        <div class=\"row\">
            {% for article in articles %}
                <div class=\"col-md-6\">
                    <div class=\"vl\">
                    <article>
                        <header>
                            <h2>{{ article.title }}</h2>
                        </header>
                        {% if article.image is not empty %}
                            <a href=\"{{ path('article_view', {id: article.id}) }}\">
                                <img src=\"{{ asset('uploads/images/articles/' ~ article.image) }}\" width=\"400px\" height=\"200px\">
                            </a>
                        {% endif %}

                        <p>
                            {{ article.summary }}
                        </p>

                        <small class=\"author\">
                            Author: {{ article.author.fullName }}
                        </small>

                        <small>
                            Views:{{ article.viewCount }}
                        </small><br>

                        <small>
                            Date Added:{{ article.dateAdded|date(\"F jS \\\\a\\\\t g:ia\") }}
                        </small>


                            <div class=\"pull-right\">
                                <div class=\"v2\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"{{ path(\"article_view\", {id:article.id}) }}\">Read more &raquo;</a>
                            </div></div>

                    </article></div>
                    <hr class=\"new\">
                </div>
            {% endfor %}
        </div>
    </div>


{% endblock %}
", "home/index.html.twig", "D:\\Projects\\php\\SoftUniBlog\\app\\Resources\\views\\home\\index.html.twig");
    }
}
